# WhiteSur-Nord-ulauncher
 A theme for Ulauncher. WhiteSur Nord theme.

## Screenshot
![](https://i.imgur.com/vC1WfFk.png)

## Installation

```sh
mkdir -p ~/.config/ulauncher/user-themes
git clone https://github.com/habibimedwassim/WhiteSur-Nord-ulauncher.git \
  ~/.config/ulauncher/user-themes/WhiteSur-Nord-ulauncher
```
